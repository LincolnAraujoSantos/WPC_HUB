(() => {
  const targetImages     = document.querySelectorAll('div.widgets-preview-h-full-horizontal img[title]');
  const expiredDivs      = document.querySelectorAll('div.widget-card-expired');
  const expiredSpanTexts = Array.from(expiredDivs)
    .flatMap(div => Array.from(div.querySelectorAll('span')).map(span => span.innerText));

  targetImages.forEach(img => {
    const titleText = img.getAttribute('title')?.trimEnd() ?? '';
    if (expiredSpanTexts.includes(titleText)) {
      img.parentNode.style.display = 'none';
    }
  });
})();
