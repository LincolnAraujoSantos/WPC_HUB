// Phase 3 — Captura full-page por scroll + sinaliza background
// Injetado sob demanda via chrome.scripting.executeScript
// TODO: implement in Phase 3
