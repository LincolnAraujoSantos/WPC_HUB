// Phase 3 — Escaneia links e classifica samsung.com vs externos
// Injetado sob demanda via chrome.scripting.executeScript
// TODO: implement in Phase 3
