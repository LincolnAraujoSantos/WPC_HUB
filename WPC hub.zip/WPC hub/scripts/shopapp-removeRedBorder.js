(() => {
  const CMS_IMG_NAME_ATTRS    = ["title", "alt", "data-name", "data-title", "aria-label"];
  const CMS_IMG_CONTAINER     = "div.widgets-preview-h-full-horizontal img";
  const CMS_IMG_NAME_SUFFIXES = [" - image url", " - Image URL", " - image URL", " - IMAGE URL"];

  function cleanImgName(val) {
    let result = val.trim();
    for (const suffix of CMS_IMG_NAME_SUFFIXES) {
      if (result.toLowerCase().endsWith(suffix.toLowerCase())) {
        result = result.slice(0, result.length - suffix.length).trim();
        break;
      }
    }
    return result;
  }

  function getImgName(img) {
    for (const attr of CMS_IMG_NAME_ATTRS) {
      const val = img.getAttribute(attr);
      if (val && val.trim() !== "") return cleanImgName(val);
    }
    return null;
  }

  function getTargetImages() {
    return Array.from(document.querySelectorAll(CMS_IMG_CONTAINER))
      .filter(img => getImgName(img) !== null);
  }

  const targetImages     = getTargetImages();
  const expiredDivs      = document.querySelectorAll('div.widget-card-expired');
  const expiredSpanTexts = Array.from(expiredDivs)
    .flatMap(div => Array.from(div.querySelectorAll('span')).map(span => span.innerText));

  targetImages.forEach(img => {
    const titleText = getImgName(img);
    const hasMatch  = expiredSpanTexts.includes(titleText);
    if (hasMatch) {
      img.parentNode.style.border = 'none';
    }
  });
})();
