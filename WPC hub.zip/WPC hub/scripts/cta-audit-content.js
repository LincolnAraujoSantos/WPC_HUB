// Phase 3 — Escaneia CTAs: vazio, espaço em URL, sem analytics
// Injetado sob demanda via chrome.scripting.executeScript
// TODO: implement in Phase 3
