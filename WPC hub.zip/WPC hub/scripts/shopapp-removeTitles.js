(() => {
  document.querySelectorAll('.cms-helper-title')
    .forEach(span => { span.style.display = 'none'; });
})();
