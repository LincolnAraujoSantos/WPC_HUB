import { showToast } from '../lib/toast.js';

export function init() {
  const inject = async file => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs.length) { showToast('Could not detect active tab.'); return; }
    await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, files: [file] });
  };

  const wire = (id, file) => {
    document.getElementById(id).addEventListener('click', async () => {
      try { await inject(file); }
      catch (err) {
        console.error('[shopapp]', err);
        showToast('Script injection failed. Open a ShopApp page first.');
      }
    });
  };

  wire('sa-addBorder',   'scripts/shopapp-addRedBorder.js');
  wire('sa-hideBorder',  'scripts/shopapp-removeRedBorder.js');
  wire('sa-showTitles',  'scripts/shopapp-addTitles.js');
  wire('sa-hideTitles',  'scripts/shopapp-removeTitles.js');
  wire('sa-showExpired', 'scripts/shopapp-showExpired.js');
  wire('sa-hideExpired', 'scripts/shopapp-hideExpired.js');
}

export function run() {}
