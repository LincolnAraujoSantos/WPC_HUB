import { showToast } from '../lib/toast.js';

const DEFAULT_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxjlwng2BoBO596y-BrhgVhHyrdq51WVv8rh0sVv3Rf71-LAT8y2omQYmqKQ7gGEEWD/exec';

async function translateText(text) {
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=pt|en`;
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (data.responseStatus === 200 && data.responseData?.translatedText) {
    return data.responseData.translatedText;
  }
  throw new Error('Invalid response from translation API');
}

export function init() {
  const qaInput = document.getElementById('r-qa');

  chrome.storage.local.get(['wpcUsername'], res => {
    if (res.wpcUsername) qaInput.value = res.wpcUsername;
  });

  document.getElementById('r-save').addEventListener('click', () => {
    const name = qaInput.value.trim();
    if (!name) return;
    chrome.storage.local.set({ wpcUsername: name }, () => {
      const btn = document.getElementById('r-save');
      btn.style.color = 'var(--green)';
      setTimeout(() => (btn.style.color = ''), 1000);
    });
  });

  document.getElementById('r-clear').addEventListener('click', () => {
    qaInput.value = '';
    chrome.storage.local.remove('wpcUsername');
  });

  document.getElementById('r-cancel').addEventListener('click', () => window.close());
  document.getElementById('r-report').addEventListener('click', sendReport);

  document.getElementById('r-translate').addEventListener('click', async () => {
    const textarea = document.getElementById('r-comments');
    const text = textarea.value.trim();
    if (!text) return showToast('Type something in Comments first.');

    const btn = document.getElementById('r-translate');
    btn.disabled = true;
    btn.textContent = '…';
    try {
      textarea.value = await translateText(text);
    } catch {
      showToast('Translation failed. Check your internet connection.');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Translate';
    }
  });
}

async function sendReport() {
  const category = document.getElementById('r-category').value;
  const sub      = document.getElementById('r-sub').value;
  const status   = document.getElementById('r-status').value;
  const qa       = document.getElementById('r-qa').value.trim();

  if (!category || !sub || !status || !qa) {
    return showToast('Please fill all mandatory fields (*)');
  }

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabs.length) return showToast('Could not detect active tab.');
  const rawUrl = tabs[0].url;

  if (!rawUrl.startsWith('https://jira.secext.samsung.net/browse/WSC')) {
    return showToast('Invalid URL. Open a WSC Jira ticket first.');
  }

  const ticketUrl    = rawUrl.split(/[?#]/)[0];
  const formattedDate = new Date().toISOString().split('T')[0].replace(/-/g, '/');

  const data = {
    ticketUrl, category, sub, status,
    publisherError:  document.getElementById('r-publisherError').value,
    pendingCustomer: document.getElementById('r-pendingCustomer').value,
    reason:          document.getElementById('r-reason').value,
    date:            formattedDate,
    qa,
    comments:        document.getElementById('r-comments').value,
  };

  const btn = document.getElementById('r-report');
  btn.disabled    = true;
  btn.textContent = 'Sending…';

  try {
    const { reportScriptUrl } = await chrome.storage.local.get(['reportScriptUrl']);
    const url = reportScriptUrl || DEFAULT_SCRIPT_URL;

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    showToast('Report sent! ✓');
    setTimeout(() => window.close(), 1200);
  } catch (err) {
    console.error('[report]', err);
    showToast('Error sending report. Check the Apps Script URL in Settings.');
    btn.disabled    = false;
    btn.textContent = 'Send Report';
  }
}

export function run() {}
