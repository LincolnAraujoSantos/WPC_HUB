# PLAN.md — WPC Hub Extension

**Plano de implementação v3.0.0**  
**Data:** 2026-06-15

---

## Visão Geral

Este plano está dividido em **4 fases** sequenciais. Cada fase entrega valor independente e pode ser testada antes de avançar para a próxima.

**Fase 1** — Scaffolding e unificação estrutural  
**Fase 2** — Migração dos módulos existentes  
**Fase 3** — Novos módulos de auditoria  
**Fase 4** — Polimento, cross-browser e distribuição

---

## Fase 1 — Scaffolding e Estrutura Base

> **Skill:** `chrome-extension-developer`  
> **Objetivo:** Criar o projeto unificado do zero, com a estrutura de arquivos correta e o manifest configurado.

### 1.1 — Criar estrutura de diretórios

O código das extensões anteriores está disponível em `extensoes-antigas/` na raiz do repositório para consulta durante a migração:

```
extensoes-antigas/
├── wpc-toolkit/      # Fonte do WPC Toolkit v2.1.0
└── snapSlide/        # Fonte do SnapSlide QA v4.1
```

Estrutura a criar dentro de `wpc-hub/`:

```
wpc-hub/
├── manifest.json
├── popup.html
├── popup.css
├── popup.js
├── icons/
├── models/          (copiar de WPC Toolkit)
├── modules/         (um .js por módulo)
└── scripts/         (content scripts)
```

**Ações:**
- Criar diretório raiz `wpc-hub/`
- Copiar ícones do WPC Toolkit (renomear icon64 → icon48 para padrão)
- Copiar modelos XLSX sem modificação

---

### 1.2 — Criar `manifest.json` unificado

**Permissões necessárias:**
```json
{
  "manifest_version": 3,
  "name": "WPC Hub",
  "version": "3.0.0",
  "description": "Suite completa de QA para o time WPC.",
  "permissions": ["activeTab", "scripting", "storage", "tabs", "clipboardWrite", "webNavigation", "debugger"],
  "host_permissions": ["<all_urls>", "https://script.google.com/*"],
  "background": { "service_worker": "scripts/background.js" },
  "action": { "default_popup": "popup.html" },
  "content_scripts": [
    { "matches": ["<all_urls>"], "js": ["scripts/countryscan-content.js"] },
    { "matches": ["<all_urls>"], "js": ["scripts/widget-organizer.js"] },
    {
      "matches": ["https://opstools-p1-*.ecom-qa.samsung.com/*"],
      "js": ["scripts/shopapp-content.js"],
      "css": ["scripts/shopapp-content.css"]
    }
  ],
  "web_accessible_resources": [{ "resources": ["models/*.xlsx"], "matches": ["<all_urls>"] }]
}
```

**Nota:** Os content scripts de auditoria (link, cta, overflow, screenshot) são injetados sob demanda via `chrome.scripting.executeScript` — não listados no manifest.

---

### 1.3 — Criar `popup.html` com shell de abas

**Estrutura de abas (10 módulos):**
```
Linha 1: [ Report ] [ Checklist ] [ QuickText ] [ SnapSlide ] [ CountryScan ]
Linha 2: [ ShopApp ] [ Screenshot ] [ Overflow ] [ CTA ] [ Links ]
```

- Cada aba tem um `<div id="tab-{nome}" class="tab-panel">`
- CSS: abas em duas linhas, tema escuro
- `popup.js` controla qual painel está ativo

---

### 1.4 — Criar `popup.css` com design system

**Tokens base (herdar do WPC Toolkit + ajustes):**
- Accent: `#1428A0` (Samsung Blue)
- Background: `#0f0f0f`, `#1a1a1a`, `#2a2a2a`
- Texto: `#ffffff`, `#a0a0a0`
- Verde: `#34c759`, Vermelho: `#ff3b30`, Laranja: `#ff9f0a`
- Fonte: `system-ui, -apple-system, sans-serif`

**Componentes a definir:**
- `.tab` / `.tab.active`
- `.tab-panel` / `.tab-panel.active`
- `.btn`, `.btn-primary`, `.btn-danger`, `.btn-ghost`
- `.field`, `label`, `input`, `select`, `textarea`
- `.result-list`, `.result-item`, `.result-badge`
- `.toast` (notificação temporária)
- `.spinner`

---

### 1.5 — Criar `popup.js` como orquestrador

**Responsabilidades do `popup.js`:**
- Sistema de navegação entre abas
- Importar e inicializar cada módulo ao ativar sua aba
- Nenhuma lógica de negócio — apenas roteamento

```javascript
// Exemplo de estrutura
import { init as initReport } from './modules/report.js';
import { init as initChecklist } from './modules/checklist.js';
// ...

const tabHandlers = {
  report: initReport,
  checklist: initChecklist,
  // ...
};

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    activateTab(tab.dataset.tab);
    tabHandlers[tab.dataset.tab]?.();
  });
});
```

---

## Fase 2 — Migração dos Módulos Existentes

> **Skill:** `chrome-extension-developer`  
> **Objetivo:** Mover a lógica do WPC Toolkit e SnapSlide para os arquivos de módulo, sem regressões.

### 2.1 — Migrar módulo Report

- **Fonte:** `extensoes-antigas/wpc-toolkit/popup.js` (MODULE 1 — REPORT)
- Extrair lógica para `modules/report.js`
- Manter mesma lógica de validação (URL deve ser `jira.secext.samsung.net/browse/WSC*`)
- Manter `SCRIPT_URL` como constante configurável no topo do arquivo
- Teste: preencher form + enviar + verificar Google Sheets

---

### 2.2 — Migrar módulo Checklist

- **Fonte:** `extensoes-antigas/wpc-toolkit/popup.js` (MODULE 2 — CHECKLIST) + `extensoes-antigas/wpc-toolkit/models/`
- Extrair para `modules/checklist.js`
- Manter lógica de `extractTicket()`, `getDateYYMMDD()`, seleção de template
- Referência aos modelos XLSX via `chrome.runtime.getURL('models/...')`
- Teste: aba Jira ativa + gerar XLSX + verificar nome do arquivo

---

### 2.3 — Migrar módulo QuickText

- **Fonte:** `extensoes-antigas/wpc-toolkit/popup.js` (MODULE 3 — QUICKTEXT)
- Extrair para `modules/quicktext.js`
- Templates inline no arquivo (sem dependência externa)
- `{user_name}` substituído via `chrome.storage.local.get('qaName')`
- Teste: copiar template + verificar clipboard

---

### 2.4 — Migrar módulo SnapSlide

- **Fonte:** `extensoes-antigas/snapSlide/Slidesfast_report/engine.js` + `index.html` + `style.css`
- Criar `modules/snapslide.js`
- Canvas de paste de imagem embutido no popup (popup tem largura 480px — canvas adapta)
- `GAS_URL` configurável no topo do arquivo
- Compatibilidade: o popup de extensão suporta paste event normalmente
- Teste: colar imagem + preencher campos + enviar + verificar Google Slides

---

### 2.5 — Migrar módulo CountryScan

- **Fonte:** `extensoes-antigas/wpc-toolkit/popup.js` (MODULE 4 — COUNTRYSCAN) + `extensoes-antigas/wpc-toolkit/scripts/countryscan-content.js`
- Extrair para `modules/countryscan.js`
- Content script `scripts/countryscan-content.js` sem modificação
- Adicionar comunicação: `chrome.tabs.sendMessage(tabId, { action: 'scanPage' })`
- Teste: abrir página Samsung + clicar Scan + verificar resultados

---

### 2.6 — Migrar módulo ShopApp

- **Fonte:** `extensoes-antigas/wpc-toolkit/popup.js` (MODULE 5 — SHOPAPP) + `extensoes-antigas/wpc-toolkit/scripts/shopapp-*.js`
- Extrair para `modules/shopapp.js`
- Content scripts `scripts/shopapp-*.js` sem modificação
- `chrome.scripting.executeScript` para injetar cada script sob demanda
- Teste: abrir opstools + executar cada ação + verificar resultado visual

---

### 2.7 — Migrar service worker

- **Fonte:** `extensoes-antigas/wpc-toolkit/scripts/background.js`
- Copiar para `scripts/background.js` sem modificação
- Verificar que SPA navigation detection do ShopApp ainda funciona
- Teste: navegar no ShopApp + verificar que Widget Organizer reaplica

---

### Checkpoint Fase 2

Antes de avançar para Fase 3:
- [ ] Todos os 6 módulos migrados funcionam sem regressão
- [ ] Extensão carrega no Chrome e Edge sem erros no DevTools
- [ ] `chrome.storage.local` persiste username entre sessões
- [ ] Nenhum `console.error` inesperado no service worker

---

## Fase 3 — Novos Módulos de Auditoria

> **Skill:** `chrome-extension-developer` para implementação  
> **Skill:** `brainstorming` se surgir dúvida de comportamento não especificado  
> **Objetivo:** Implementar os 4 novos módulos.

### 3.1 — Screenshot Engine

**Arquivos a criar:**
- `modules/screenshot.js` — lógica do popup
- `scripts/screenshot-content.js` — injetado na página para captura

**Implementação do content script (`screenshot-content.js`):**
```javascript
// Captura full-page por scroll
async function captureFullPage(viewportWidth, viewportHeight) {
  const totalHeight = document.body.scrollHeight;
  const sections = Math.ceil(totalHeight / viewportHeight);
  const images = [];
  
  for (let i = 0; i < sections; i++) {
    window.scrollTo(0, i * viewportHeight);
    await delay(300); // aguarda lazy loading
    // Sinaliza ao background para capturar
    images.push(await chrome.runtime.sendMessage({ action: 'captureTab' }));
  }
  
  window.scrollTo(0, 0);
  return images; // background faz stitch via canvas
}
```

**Implementação do módulo (`screenshot.js`):**
1. Botão "Capturar Desktop" → injeta content script em modo desktop, coleta capturas, faz stitch
2. Botão "Capturar Mobile" → usa `chrome.debugger.attach` + `Emulation.setDeviceMetricsOverride` (390×844) → captura → detach
3. Preview via `<img src="data:image/png;base64,...">` no popup
4. Botão Download: `chrome.downloads.download({ url: dataUrl, filename: 'screenshot.png' })`
5. Botão "Enviar para SnapSlide": evento customizado que preenche canvas do módulo SnapSlide

**Adição ao manifest:**
```json
"permissions": [..., "downloads"]
```

---

### 3.2 — Text Overflow Detector

**Arquivos a criar:**
- `modules/text-overflow.js`
- `scripts/text-overflow-content.js`

**Lógica do content script:**
```javascript
function detectOverflow() {
  const results = [];
  const allElements = document.querySelectorAll('*');
  
  allElements.forEach(el => {
    const style = getComputedStyle(el);
    const isHidden = style.overflow === 'hidden' || style.overflow === 'clip'
                  || style.overflowX === 'hidden' || style.overflowY === 'hidden';
    if (!isHidden) return;
    if (el.scrollHeight <= el.clientHeight && el.scrollWidth <= el.clientWidth) return;
    if (style.display === 'none' || style.visibility === 'hidden') return;
    if (el.clientWidth === 0 && el.clientHeight === 0) return;
    
    const text = el.innerText?.trim().substring(0, 100);
    if (!text) return;
    
    results.push({
      tag: el.tagName.toLowerCase(),
      text,
      selector: getCssSelector(el),
      scrollH: el.scrollHeight,
      clientH: el.clientHeight,
    });
  });
  
  return results;
}
```

**Módulo popup (`text-overflow.js`):**
1. Botão "Escanear Página" → injeta e executa content script → recebe lista
2. Renderiza lista com tag, trecho de texto, dimensões
3. Botão "Destacar na Página" → injeta script que adiciona `outline: 2px solid red`
4. Botão "Limpar" → remove outline
5. Botão "Copiar Lista" → copia texto formatado para clipboard

---

### 3.3 — CTA Audit

**Arquivos a criar:**
- `modules/cta-audit.js`
- `scripts/cta-audit-content.js`

**Lógica do content script:**
```javascript
function auditCTAs() {
  const results = { empty: [], spacedUrl: [], noAnalytics: [] };
  
  document.querySelectorAll('a, button').forEach(el => {
    const text = el.innerText?.trim() || '';
    const ariaLabel = el.getAttribute('aria-label') || '';
    const href = el.getAttribute('href') || '';
    
    // CTA vazio
    if (!text && !ariaLabel) {
      results.empty.push({ tag: el.tagName.toLowerCase(), href, selector: getCssSelector(el) });
    }
    
    // URL com espaço (apenas para <a>)
    if (el.tagName === 'A' && href.includes(' ')) {
      results.spacedUrl.push({ text, href, selector: getCssSelector(el) });
    }
    
    // Sem analytics (apenas para <a> com href externo)
    if (el.tagName === 'A' && href.startsWith('http')) {
      const hasAnalytics = href.includes('utm_') || href.includes('cid=')
        || el.hasAttribute('data-analytics') || el.hasAttribute('data-tracking')
        || el.dataset.analytics || el.dataset.tracking;
      if (!hasAnalytics) {
        results.noAnalytics.push({ text, href, selector: getCssSelector(el) });
      }
    }
  });
  
  return results;
}
```

**Módulo popup (`cta-audit.js`):**
1. Botão "Auditar CTAs" → injeta e executa → recebe objeto com três listas
2. Exibe contadores por categoria (vermelho se > 0)
3. Lista expansível por categoria
4. Botão "Destacar" por categoria (borda laranja nos elementos)
5. Botão "Copiar Relatório"

---

### 3.4 — Link Audit

**Arquivos a criar:**
- `modules/link-audit.js`
- `scripts/link-audit-content.js`

**Lógica do content script:**
```javascript
function auditLinks() {
  const summary = { total: 0, samsung: 0, external: 0, violations: 0 };
  const violations = [];
  
  document.querySelectorAll('a[href]').forEach(el => {
    const href = el.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('javascript:')
        || href.startsWith('mailto:') || href.startsWith('tel:')) return;
    
    summary.total++;
    const target = el.getAttribute('target') || '_self';
    const isSamsung = (() => {
      try { return new URL(href).hostname.endsWith('.samsung.com'); }
      catch { return false; }
    })();
    
    if (isSamsung) {
      summary.samsung++;
      // Deve abrir na mesma aba
      if (target === '_blank') {
        summary.violations++;
        violations.push({
          href, text: el.innerText?.trim().substring(0, 60),
          targetActual: '_blank', targetExpected: '_self',
          type: 'samsung-opens-new-tab',
          selector: getCssSelector(el)
        });
      }
    } else {
      summary.external++;
      // Deve abrir em nova aba
      if (target !== '_blank') {
        summary.violations++;
        violations.push({
          href, text: el.innerText?.trim().substring(0, 60),
          targetActual: target, targetExpected: '_blank',
          type: 'external-opens-same-tab',
          selector: getCssSelector(el)
        });
      }
    }
  });
  
  return { summary, violations };
}
```

**Módulo popup (`link-audit.js`):**
1. Botão "Auditar Links" → injeta e executa → recebe summary + violations
2. Exibe painel de resumo: total / samsung / externos / violações
3. Lista de violações com tipo, texto do link, href, target atual vs esperado
4. Botão "Destacar Violações" (borda vermelha)
5. Botão "Limpar" e "Copiar Relatório"

---

### Checkpoint Fase 3

Antes de avançar para Fase 4:
- [ ] Screenshot captura full-page em modo desktop sem erros
- [ ] Screenshot mobile usando `chrome.debugger` funciona no Chrome e Edge
- [ ] Text Overflow lista elementos reais em páginas Samsung (não vazio, não lixo)
- [ ] CTA Audit detecta corretamente links sem UTM em páginas de teste
- [ ] Link Audit classifica corretamente samsung.com vs externos
- [ ] Nenhum dos módulos quebra a performance da página inspecionada

---

## Fase 4 — Polimento, Cross-browser e Distribuição

> **Skill:** `chrome-extension-developer`, `frontend-design`  
> **Objetivo:** Extensão pronta para uso real pelo time.

### 4.1 — Ajustes de UX

- Revisar layout do popup com 10 abas — considerar abas em duas linhas ou scroll
- Adicionar tooltip em cada botão
- Estado de loading (spinner) em todas as operações assíncronas
- Toast de sucesso/erro padronizado para todos os módulos
- Scroll position preservado ao voltar para a mesma aba

---

### 4.2 — Compatibilidade Edge

- Testar instalação manual no Edge (processo idêntico ao Chrome)
- Verificar `chrome.debugger` no Edge (deve funcionar — Edge usa mesmo engine)
- Verificar que `chrome.scripting.executeScript` retorna valores corretamente no Edge

---

### 4.3 — Polyfill para Firefox (preparação futura)

- Adicionar `browser-polyfill.js` (WebExtensions) como `<script>` no popup.html
- Substituir `chrome.*` por `browser.*` com `const api = typeof browser !== 'undefined' ? browser : chrome`
- **Não testar no Firefox agora — apenas preparar o código para v3.1**

---

### 4.4 — Configurações persistentes

Criar aba "Settings" (ou modal) com:
- Username (já existe, unificar os dois campos de username do Report e Checklist)
- SCRIPT_URL do Report (editável)
- GAS_URL do SnapSlide (editável)
- ID da apresentação padrão do SnapSlide (editável, já existe no HTML)

Todos salvos em `chrome.storage.local`.

---

### 4.5 — Empacotamento para distribuição

```bash
# Script de build (criar scripts/build.sh)
zip -r wpc-hub-v3.0.0.zip \
  manifest.json popup.html popup.css popup.js \
  icons/ models/ modules/ scripts/ \
  --exclude "*.DS_Store" --exclude "*.git*"
```

- README com instruções de instalação manual
- Changelog atualizado

---

## Resumo do Plano

| Fase | Entregável | Estimated |
|------|-----------|-----------|
| Fase 1 | Scaffolding + manifest + popup shell | ~1 sessão |
| Fase 2 | Todos os módulos existentes migrados | ~2 sessões |
| Fase 3 | 4 novos módulos de auditoria | ~2 sessões |
| Fase 4 | Polimento + distribuição | ~1 sessão |

---

## Quando usar skills durante a implementação

| Situação | Ação |
|----------|------|
| Começar qualquer fase | Reler `CLAUDE.md` para relembrar convenções |
| Comportamento de um módulo não está claro no PRD | Parar e usar skill `brainstorming` |
| Criar ou modificar UI do popup | Consultar skill `frontend-design` |
| Dúvida sobre API do Chrome/Edge/Firefox | Consultar skill `chrome-extension-developer` |
| Qualquer nova feature não listada aqui | Usar skill `brainstorming` antes de implementar |
