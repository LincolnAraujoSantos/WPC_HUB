# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

**WPC Hub** — extensão web cross-browser (Chrome + Edge + Firefox) para o time de QA do WPC Samsung.

---

## O que é este projeto

**WPC Hub** unifica o WPC Toolkit (6 módulos) e o SnapSlide QA em uma única extensão Manifest V3, e adiciona 4 novos módulos de auditoria de página. Compatível com Chrome, Edge e Firefox (via WebExtensions API).

---

## Skills disponíveis

Antes de qualquer trabalho, verifique qual skill aplicar:

| Situação | Skill a usar |
|----------|-------------|
| Criar nova funcionalidade, componente ou módulo | `brainstorming` — obrigatório antes de qualquer código |
| Construir ou modificar a UI do popup | `frontend-design` |
| Criar ou modificar arquivos de extensão (manifest, service worker, content scripts) | `chrome-extension-developer` |
| Planejar uma nova feature ou roadmap | `product-manager` |

**Regra geral:** Toda nova feature passa pelo fluxo `brainstorming → spec aprovado → implementação`. Não pule etapas.

---

## Estrutura do repositório raiz

```
wpc-hub/                        # Projeto principal — todo o desenvolvimento acontece aqui
├── skills/                     # Skills do Claude Code
├── CLAUDE.md
├── PRD.md
├── PLAN.md
└── (código da extensão criado aqui)

extensoes-antigas/              # Referência somente leitura — apagar após migração completa
├── wpc-toolkit/
└── snapSlide/
```

Durante a migração, o Claude Code pode ler livremente a pasta `extensoes-antigas/` como referência. **Nunca modificar arquivos lá dentro.** Quando todos os módulos estiverem migrados e testados no WPC Hub, a pasta `extensoes-antigas/` deve ser deletada.

---

## Arquitetura da extensão

```
wpc-hub/
├── manifest.json               # Manifest V3, cross-browser
├── popup.html                  # Shell com abas (tabs)
├── popup.css                   # Design system — tema escuro Samsung
├── popup.js                    # Orquestrador — carrega módulos por aba
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── models/                     # Templates XLSX de checklist
│   └── *.xlsx
├── modules/                    # Um arquivo JS por módulo
│   ├── report.js               # Envia relatório para Google Sheets
│   ├── checklist.js            # Gera XLSX de checklist
│   ├── quicktext.js            # Copia templates de comentário
│   ├── snapslide.js            # Cola print + envia para Google Slides
│   ├── countryscan.js          # Analisa idioma, país, assets, CTAs
│   ├── shopapp.js              # Helper do CMS ShopApp
│   ├── screenshot.js           # Captura desktop + mobile da página
│   ├── text-overflow.js        # Detecta textos cortados
│   ├── cta-audit.js            # Audita CTAs vazios e analytics
│   └── link-audit.js           # Valida links samsung.com vs externos
└── scripts/                    # Content scripts injetados nas páginas
    ├── background.js           # Service worker
    ├── countryscan-content.js  # Injetado em todas as páginas
    ├── widget-organizer.js     # Badges e botão de data no CMS
    ├── shopapp-content.js      # Injetado nas páginas Offerv2
    ├── shopapp-content.css
    ├── screenshot-content.js   # Captura de tela e viewport mobile
    ├── text-overflow-content.js # Detecta overflow na página
    ├── cta-audit-content.js    # Escaneia CTAs na página
    ├── link-audit-content.js   # Escaneia links na página
    └── shopapp-*.js            # Helpers visuais do ShopApp
```

---

## Módulos e responsabilidades

### Módulos herdados (WPC Toolkit)

| Módulo | Arquivo | O que faz |
|--------|---------|-----------|
| Report | `modules/report.js` | Captura URL do ticket Jira e envia relatório estruturado para Google Sheets via Apps Script |
| Checklist | `modules/checklist.js` | Gera .xlsx de QA nomeado pela URL do ticket + username + data |
| QuickText | `modules/quicktext.js` | Copia templates de comentários QA para o clipboard |
| CountryScan | `modules/countryscan.js` | Escaneia idioma, país, assets e CTAs da página ativa |
| ShopApp | `modules/shopapp.js` | Injeta helpers visuais no CMS opstools-p1-*.ecom-qa.samsung.com |

### Módulo herdado (SnapSlide QA)

| Módulo | Arquivo | O que faz |
|--------|---------|-----------|
| SnapSlide | `modules/snapslide.js` | Cola screenshot via Ctrl+V e envia com categoria de erro para Google Slides via Apps Script |

### Módulos novos

| Módulo | Arquivo | O que faz |
|--------|---------|-----------|
| Screenshot Engine | `modules/screenshot.js` | Captura a página completa em viewport desktop e mobile simulado |
| Text Overflow Detector | `modules/text-overflow.js` | Detecta textos cortados visualmente (overflow: hidden com conteúdo excedente) |
| CTA Audit | `modules/cta-audit.js` | Detecta CTAs sem texto, links com espaço na URL, links sem parâmetros de analytics |
| Link Audit | `modules/link-audit.js` | Valida comportamento de abertura — samsung.com/* deve abrir na mesma aba, externos em nova aba |

---

## Convenções de código

### Manifest V3
- Sempre usar **Service Worker** em vez de Background Page
- Usar `chrome.storage.local` para persistência — nunca `localStorage`
- Comunicação popup ↔ content scripts via `chrome.runtime.sendMessage` / `chrome.tabs.sendMessage`
- Retornar `true` no listener para manter o canal aberto em respostas assíncronas

### Content scripts
- Cada módulo novo tem seu próprio content script em `scripts/`
- Content scripts não têm acesso à DOM do popup — comunicam apenas via mensagens
- Injetar via `chrome.scripting.executeScript` para execução sob demanda (não listar no manifest para módulos de auditoria)

### Módulos JS
- Um arquivo por módulo em `modules/`
- Cada módulo exporta uma função `init(tabId)` e `run(tabId, options)`
- `popup.js` orquestra: ao clicar na aba, chama `init()`; ao clicar em executar, chama `run()`

### Cross-browser
- Usar `chrome.*` API — WebExtensions polyfill garante compatibilidade com Firefox
- Evitar APIs exclusivas do Chrome sem fallback

### UI
- Tema escuro, cores Samsung
- Popup com largura fixa 420px, altura auto (máx 600px com scroll)
- Aba por módulo; abas novas adicionadas no final

---

## Fluxo de mensagens (content script ↔ popup)

```
popup.js
  └── chrome.tabs.sendMessage(tabId, { action: 'auditLinks' })
        └── link-audit-content.js
              └── sendResponse({ links: [...] })
  └── recebe resposta e renderiza no popup
```

---

## Regras de negócio críticas

### Link Audit
- Qualquer URL cujo hostname termina em `samsung.com` (ex: `www.samsung.com`, `opstools-p1-br.ecom-qa.samsung.com`, `image-us.samsung.com`) → deve abrir na mesma aba (`target="_self"` ou ausente)
- Qualquer outra URL externa → deve ter `target="_blank"` (nova aba)
- Detecção via `new URL(href).hostname.endsWith('.samsung.com')` — cobre www, subdomínios de produção e ambientes de teste
- Reportar violações com seletor CSS do elemento

### CTA Audit
- CTA vazio: `<a>` ou `<button>` sem texto visível (innerText vazio após trim)
- Link com espaço na URL: `href` contém caractere de espaço (` ` ou `%20` em posição inesperada)
- Sem analytics: link sem parâmetros `utm_*` ou `cid=` ou atributos `data-analytics-*`

### Screenshot Engine
- Desktop: viewport 1920×1080
- Mobile: viewport 390×844 (iPhone 14), user-agent móvel simulado via `chrome.debugger` ou CSS media override
- Captura via `chrome.tabs.captureVisibleTab` com scroll automático (stitch)

### CountryScan — países suportados
`br, co, cl, mx, pe, ar, uy, py, latin, latin_en`

---

## Desenvolvimento

**Carregar a extensão no Chrome / Edge (sem build step):**
1. Abrir `chrome://extensions` (ou `edge://extensions`)
2. Ativar "Modo do desenvolvedor"
3. Clicar "Carregar sem compactação" → selecionar a pasta `wpc-hub/`
4. Após editar qualquer arquivo: botão de reload na listagem de extensões → reabrir o popup

**Inspecionar o popup:**
- Clique com botão direito no ícone da extensão → "Inspecionar popup" → DevTools abre vinculado ao popup

**Inspecionar o service worker:**
- Em `chrome://extensions`, clicar em "Service Worker" ao lado da extensão

**Empacotar para distribuição:**
```bash
# Zip excluindo artefatos desnecessários
zip -r wpc-hub-v3.0.0.zip manifest.json popup.html popup.css popup.js icons/ models/ modules/ scripts/ --exclude "*.DS_Store"
```

A extensão não tem dependências de build — todos os arquivos são JS/CSS/HTML nativos carregados diretamente pelo browser.

---

## Quando usar cada skill durante o desenvolvimento

**Adicionando um novo módulo de auditoria:**
1. Usar skill `brainstorming` — explorar requisitos, propor abordagem
2. Aprovado o spec → usar skill `chrome-extension-developer` para implementação
3. Usar skill `frontend-design` ao criar a aba no popup

**Refatorando módulo existente:**
1. Usar skill `chrome-extension-developer` diretamente se mudança é técnica clara
2. Se a mudança afeta UX ou comportamento, passar por `brainstorming` primeiro

**Criando templates ou documentação:**
1. Usar skill `product-manager` para estruturar PRDs, métricas ou roadmap

---

## Não fazer

- ❌ Não usar `innerHTML` com conteúdo externo — usar `textContent` ou DOM API
- ❌ Não usar `eval()` em nenhum contexto
- ❌ Não bloquear o service worker com operações síncronas longas
- ❌ Não adicionar permissões desnecessárias ao manifest
- ❌ Não criar conteúdo direto no popup sem passar por mensagens quando o dado vem da página
